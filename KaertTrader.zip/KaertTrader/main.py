import streamlit as st
import plotly.graph_objects as go
from utils.market_data import (
    get_market_data, get_supported_pairs, get_time_patterns, 
    get_timeframes, calculate_coin_confidence
)
from utils.technical_indicators import calculate_indicators
from utils.signal_generator import generate_trading_signals
from utils.educational_content import get_educational_content
import pandas as pd

st.set_page_config(
    page_title="Binary Trading Signals Dashboard",
    page_icon="📈",
    layout="wide"
)

# Load custom CSS
with open('assets/styles.css') as f:
    st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

# Sidebar
st.sidebar.title("Trading Signals Dashboard")

# Asset Selection
asset_categories = get_supported_pairs()
category = st.sidebar.selectbox("Select Asset Category", list(asset_categories.keys()))
ticker = st.sidebar.selectbox("Select Asset", asset_categories[category])

# Time Settings
timeframes = get_timeframes()
selected_timeframe = st.sidebar.selectbox(
    "Select Timeframe",
    options=range(len(timeframes)),
    format_func=lambda x: f"{timeframes[x][0]} (last {timeframes[x][1]})"
)
interval, period = timeframes[selected_timeframe]

# Advanced Settings
with st.sidebar.expander("Advanced Settings"):
    signal_threshold = st.slider("Signal Confidence Threshold", 30, 90, 60)
    show_all_indicators = st.checkbox("Show All Technical Indicators", False)
    show_prime_analysis = st.checkbox("Show Time Prime Analysis", True)

# Disclaimer
st.sidebar.markdown("""
---
**Disclaimer**: This is an educational tool for learning purposes only. 
Do not use these signals for actual trading decisions.
""")

# Main content
st.title("📊 Advanced Trading Signals Dashboard")

# Load market data
df = get_market_data(ticker, period, interval)

if df is not None:
    # Calculate indicators and signals
    indicators = calculate_indicators(df)
    signals = generate_trading_signals(indicators, df)
    time_patterns = get_time_patterns(df)

    # Calculate coin confidence if it's a crypto asset
    coin_confidence = None
    if category in ['Crypto', 'Crypto Futures']:
        coin_confidence = calculate_coin_confidence(df)

    # Create tabs
    tab1, tab2, tab3, tab4 = st.tabs(["Trading Signals", "Technical Analysis", "Time Patterns", "Educational Resources"])

    with tab1:
        st.header("Binary Trading Signals")

        # Latest Signal
        latest_signal = signals['binary_signal'].iloc[-1]
        latest_confidence = signals['confidence'].iloc[-1]
        signal_strength = signals['strength'].iloc[-1]

        col1, col2, col3 = st.columns(3)
        with col1:
            signal_text = "🔼 UP" if latest_signal > 0 else "🔽 DOWN" if latest_signal < 0 else "⏺️ NEUTRAL"
            signal_color = "green" if latest_signal > 0 else "red" if latest_signal < 0 else "gray"
            st.markdown(f"""
            <h2 style='color: {signal_color}; text-align: center;'>
                Current Signal: {signal_text}
            </h2>
            """, unsafe_allow_html=True)

        with col2:
            st.metric("Signal Confidence", f"{latest_confidence:.1f}%")
            st.write(f"Signal Strength: {signal_strength}")

        with col3:
            st.metric("Current Price", f"${df['Close'].iloc[-1]:.2f}")
            if coin_confidence:
                st.metric("Coin Confidence", f"{coin_confidence['overall_score']:.1f}%")

        # Coin Confidence Details (if available)
        if coin_confidence:
            st.subheader("Coin Confidence Metrics")
            conf_col1, conf_col2, conf_col3 = st.columns(3)
            with conf_col1:
                st.metric("Volume Score", f"{coin_confidence['volume_score']:.1f}%")
            with conf_col2:
                st.metric("Trend Score", f"{coin_confidence['trend_score']:.1f}%")
            with conf_col3:
                st.metric("Volatility Score", f"{coin_confidence['volatility_score']:.1f}%")

        # Show TP/SL levels if available
        if signals['take_profit'].iloc[-1] is not None:
            st.subheader("Trade Levels")
            levels_col1, levels_col2 = st.columns(2)

            with levels_col1:
                tp_price = signals['take_profit'].iloc[-1]
                current_price = df['Close'].iloc[-1]
                tp_pct = abs((tp_price - current_price) / current_price * 100)
                st.metric(
                    "Take Profit Target", 
                    f"${tp_price:.4f}",
                    f"{tp_pct:.1f}% {'profit' if latest_signal > 0 else 'down'}"
                )

            with levels_col2:
                sl_price = signals['stop_loss'].iloc[-1]
                sl_pct = abs((sl_price - current_price) / current_price * 100)
                st.metric(
                    "Stop Loss Level", 
                    f"${sl_price:.4f}",
                    f"{sl_pct:.1f}% {'loss' if latest_signal > 0 else 'up'}"
                )

            # Add Risk/Reward Ratio
            if latest_signal != 0:
                tp_distance = abs(tp_price - current_price)
                sl_distance = abs(sl_price - current_price)
                risk_reward = tp_distance / sl_distance if sl_distance > 0 else 0
                st.metric("Risk/Reward Ratio", f"{risk_reward:.2f}")


        # Signal Chart
        fig = go.Figure()

        # Price
        fig.add_trace(go.Candlestick(x=df.index,
                                    open=df['Open'],
                                    high=df['High'],
                                    low=df['Low'],
                                    close=df['Close'],
                                    name='Price'))

        # Signals
        up_signals = signals[signals['binary_signal'] == 1].index
        down_signals = signals[signals['binary_signal'] == -1].index

        fig.add_trace(go.Scatter(
            x=up_signals,
            y=df.loc[up_signals, 'Low'] * 0.99,
            mode='markers',
            marker=dict(symbol='triangle-up', size=15, color='green'),
            name='Up Signal'
        ))

        fig.add_trace(go.Scatter(
            x=down_signals,
            y=df.loc[down_signals, 'High'] * 1.01,
            mode='markers',
            marker=dict(symbol='triangle-down', size=15, color='red'),
            name='Down Signal'
        ))

        fig.update_layout(
            title=f"{ticker} Price Chart with Signals ({interval} timeframe)",
            yaxis_title="Price",
            xaxis_title="Date/Time"
        )
        st.plotly_chart(fig, use_container_width=True)

        # Signal History
        st.subheader("Recent Signals")
        signal_history = pd.DataFrame({
            'Time': signals.index[-5:],
            'Signal': signals['binary_signal'].iloc[-5:].map({1: '🔼 UP', -1: '🔽 DOWN', 0: '⏺️ NEUTRAL'}),
            'Confidence': signals['confidence'].iloc[-5:].round(1).astype(str) + '%',
            'Strength': signals['strength'].iloc[-5:]
        })
        st.dataframe(signal_history, use_container_width=True)

        # Futures-specific metrics
        if 'LeverageRatio' in df.columns:
            st.subheader("Futures Market Metrics")
            fut_col1, fut_col2 = st.columns(2)
            with fut_col1:
                st.metric("Leverage Ratio", f"{df['LeverageRatio'].iloc[-1]:.2f}x")
            with fut_col2:
                st.metric("Open Interest", f"{df['OpenInterest'].iloc[-1]:,.0f}")

    with tab2:
        st.header("Technical Analysis")

        col1, col2 = st.columns(2)
        with col1:
            # RSI Chart
            fig_rsi = go.Figure()
            fig_rsi.add_trace(go.Scatter(x=indicators.index, y=indicators['RSI'],
                                        mode='lines', name='RSI'))
            fig_rsi.add_hline(y=70, line_dash="dash", line_color="red")
            fig_rsi.add_hline(y=30, line_dash="dash", line_color="green")
            fig_rsi.update_layout(title="RSI",
                                yaxis_title="RSI Value")
            st.plotly_chart(fig_rsi, use_container_width=True)

        with col2:
            # MACD Chart
            fig_macd = go.Figure()
            fig_macd.add_trace(go.Scatter(x=indicators.index, y=indicators['MACD'],
                                        mode='lines', name='MACD'))
            fig_macd.add_trace(go.Scatter(x=indicators.index, y=indicators['Signal_Line'],
                                        mode='lines', name='Signal Line'))
            fig_macd.update_layout(title="MACD",
                                yaxis_title="Value")
            st.plotly_chart(fig_macd, use_container_width=True)

        # Moving Averages with Bollinger Bands
        fig_ma = go.Figure()
        fig_ma.add_trace(go.Scatter(x=df.index, y=df['Close'],
                                    mode='lines', name='Price'))
        fig_ma.add_trace(go.Scatter(x=df.index, y=indicators['BB_Upper'],
                                    mode='lines', name='Upper BB', line=dict(dash='dash')))
        fig_ma.add_trace(go.Scatter(x=df.index, y=indicators['BB_Lower'],
                                    mode='lines', name='Lower BB', line=dict(dash='dash')))
        fig_ma.add_trace(go.Scatter(x=df.index, y=indicators['SMA_20'],
                                    mode='lines', name='20-period SMA'))
        fig_ma.add_trace(go.Scatter(x=df.index, y=indicators['EMA_50'],
                                    mode='lines', name='50-period EMA'))
        fig_ma.update_layout(title="Price with Bollinger Bands & Moving Averages",
                            yaxis_title="Price")
        st.plotly_chart(fig_ma, use_container_width=True)

    with tab3:
        st.header("Time-Based Pattern Analysis")

        col1, col2 = st.columns(2)

        with col1:
            st.subheader("Optimal Trading Times")
            if 'BestMinutes' in time_patterns:
                st.write("Best Minutes:")
                for hour, minute in time_patterns['BestMinutes']:
                    st.write(f"- {hour:02d}:{minute:02d} UTC")

            st.write("Best Hours (UTC):", ", ".join(f"{h:02d}:00" for h in time_patterns['BestTradingHours']))
            st.write("Best Days:", ", ".join([['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d] for d in time_patterns['BestTradingDays']]))

        with col2:
            if show_prime_analysis:
                st.subheader("Prime Volatility Periods")
                st.write("Top volatility times (UTC):")
                for hour, minute in time_patterns['PrimeVolatilityPeriods'][:5]:
                    st.write(f"- {hour:02d}:{minute:02d}")

        # Returns Analysis
        if 'Minute' in df.columns:
            minute_changes = df.groupby(['Hour', 'Minute'])['PriceChange'].mean()
            fig_minute = go.Figure()
            fig_minute.add_trace(go.Heatmap(
                x=minute_changes.index.get_level_values('Minute'),
                y=minute_changes.index.get_level_values('Hour'),
                z=minute_changes.values * 100,
                colorscale='RdYlGn',
                name='Returns'
            ))
            fig_minute.update_layout(
                title="Average Returns by Time (Heatmap)",
                xaxis_title="Minute",
                yaxis_title="Hour (UTC)"
            )
            st.plotly_chart(fig_minute, use_container_width=True)

    with tab4:
        st.header("Educational Resources")
        st.markdown("""
        ### Understanding Trading Signals

        Our signals are generated using multiple technical indicators:
        1. **RSI (Relative Strength Index)**
           - Oversold (RSI < 30) suggests potential UP signal
           - Overbought (RSI > 70) suggests potential DOWN signal

        2. **Moving Average Crossover**
           - Golden Cross (Short MA crosses above Long MA) - UP signal
           - Death Cross (Short MA crosses below Long MA) - DOWN signal

        3. **MACD (Moving Average Convergence Divergence)**
           - MACD crossing above Signal Line - Bullish
           - MACD crossing below Signal Line - Bearish

        4. **Bollinger Bands**
           - Price near lower band with positive momentum - Potential UP
           - Price near upper band with negative momentum - Potential DOWN

        ### Time-Based Analysis
        - **Prime Time Periods**: High volatility periods that often present trading opportunities
        - **Optimal Trading Hours**: Hours with historically better returns
        - **Pattern Recognition**: Analysis of recurring market patterns

        ### Coin Confidence Score
        The coin confidence score is calculated based on:
        - Volume Analysis: Comparing recent volume to historical averages
        - Trend Strength: Measuring the consistency of price movements
        - Volatility Score: Assessing price stability
        """)

        educational_content = get_educational_content()
        for section in educational_content:
            with st.expander(section['title']):
                st.markdown(section['content'])

else:
    st.error("Unable to fetch market data. Please check the symbol and try again.")