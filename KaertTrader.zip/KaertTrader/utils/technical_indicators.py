import pandas as pd
import numpy as np

def calculate_indicators(df):
    """
    Calculate technical indicators

    Args:
        df (pandas.DataFrame): Market data

    Returns:
        pandas.DataFrame: Technical indicators
    """
    indicators = pd.DataFrame(index=df.index)

    # Basic Indicators
    # RSI
    delta = df['Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    indicators['RSI'] = 100 - (100 / (1 + rs))

    # Moving Averages
    indicators['SMA_20'] = df['Close'].rolling(window=20).mean()
    indicators['EMA_50'] = df['Close'].ewm(span=50, adjust=False).mean()

    # Advanced Indicators
    # MACD
    exp1 = df['Close'].ewm(span=12, adjust=False).mean()
    exp2 = df['Close'].ewm(span=26, adjust=False).mean()
    indicators['MACD'] = exp1 - exp2
    indicators['Signal_Line'] = indicators['MACD'].ewm(span=9, adjust=False).mean()

    # Bollinger Bands
    indicators['BB_Middle'] = df['Close'].rolling(window=20).mean()
    bb_std = df['Close'].rolling(window=20).std()
    indicators['BB_Upper'] = indicators['BB_Middle'] + (bb_std * 2)
    indicators['BB_Lower'] = indicators['BB_Middle'] - (bb_std * 2)

    # Stochastic Oscillator
    low_min = df['Low'].rolling(window=14).min()
    high_max = df['High'].rolling(window=14).max()
    indicators['%K'] = ((df['Close'] - low_min) / (high_max - low_min)) * 100
    indicators['%D'] = indicators['%K'].rolling(window=3).mean()

    # Average True Range (ATR)
    high_low = df['High'] - df['Low']
    high_close = abs(df['High'] - df['Close'].shift())
    low_close = abs(df['Low'] - df['Close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = ranges.max(axis=1)
    indicators['ATR'] = true_range.rolling(window=14).mean()

    # Price Channels
    indicators['Upper_Channel'] = df['High'].rolling(window=20).max()
    indicators['Lower_Channel'] = df['Low'].rolling(window=20).min()

    # Volume Indicators
    indicators['OBV'] = (np.sign(df['Close'].diff()) * df['Volume']).cumsum()

    return indicators