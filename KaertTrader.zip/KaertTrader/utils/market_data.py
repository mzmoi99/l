import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

def get_supported_pairs():
    """
    Returns a list of supported currency pairs and symbols
    """
    return {
        'Forex': [
            'EURUSD=X', 'GBPUSD=X', 'USDJPY=X', 'AUDUSD=X', 'USDCAD=X',
            'USDCHF=X', 'NZDUSD=X', 'EURJPY=X', 'GBPJPY=X', 'EURGBP=X',
            'AUDNZD=X', 'USDMXN=X', 'USDBRL=X', 'USDTRY=X'
        ],
        'Crypto': [
            'BTC-USD', 'ETH-USD', 'XRP-USD', 'DOGE-USD', 'ADA-USD',
            'DOT-USD', 'UNI-USD', 'LINK-USD', 'MATIC-USD', 'SOL-USD',
            'AVAX-USD', 'AAVE-USD', 'SNX-USD', 'COMP-USD'
        ],
        'Crypto Futures': [
            'BTC-USD', 'ETH-USD', 'XRP-USD', 'BNB-USD', 'ADA-USD',
            'DOT-USD', 'MATIC-USD', 'SOL-USD', 'AVAX-USD', 'LINK-USD'
        ],
        'Stocks': ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 'META', 'NVDA'],
        'Commodities': ['GC=F', 'SI=F', 'CL=F', 'NG=F', 'PL=F', 'HG=F']  # Gold, Silver, Oil, Gas, Platinum, Copper
    }

def get_timeframes():
    """
    Returns available timeframes for analysis
    """
    return [
        ('30s', '1d'),    # 30 seconds data for last day
        ('1m', '1d'),     # 1 minute data for last day
        ('2m', '1d'),     # 2 minutes data for last day
        ('5m', '5d'),     # 5 minutes data for last 5 days
        ('15m', '5d'),    # 15 minutes data for last 5 days
        ('30m', '10d'),   # 30 minutes data for last 10 days
        ('1h', '1mo'),    # 1 hour data for last month
        ('1d', '1mo'),    # Daily data for last month
        ('1d', '3mo'),    # Daily data for last 3 months
        ('1d', '6mo'),    # Daily data for last 6 months
        ('1d', '1y'),     # Daily data for last year
    ]

def calculate_coin_confidence(df):
    """
    Calculate coin confidence metrics
    """
    confidence = {}

    # Volume Analysis
    avg_volume = df['Volume'].mean()
    recent_volume = df['Volume'].tail(5).mean()
    volume_score = min(100, (recent_volume / avg_volume) * 100)
    confidence['volume_score'] = volume_score

    # Trend Strength
    price_change = df['Close'].pct_change()
    trend_strength = abs(price_change.mean()) * 1000
    confidence['trend_score'] = min(100, trend_strength * 100)

    # Volatility
    volatility = df['Close'].pct_change().std() * 100
    confidence['volatility_score'] = max(0, 100 - volatility * 10)

    # Overall Score
    confidence['overall_score'] = (confidence['volume_score'] + 
                                 confidence['trend_score'] + 
                                 confidence['volatility_score']) / 3

    return confidence

def get_market_data(symbol, period, interval='1d'):
    """
    Fetch market data using yfinance with specified interval
    """
    try:
        stock = yf.Ticker(symbol)
        df = stock.history(period=period, interval=interval)

        if df.empty:
            raise ValueError(f"No data found for symbol {symbol}")

        # Add time-based features
        df['Hour'] = df.index.hour
        df['Minute'] = df.index.minute
        df['DayOfWeek'] = df.index.dayofweek
        df['Month'] = df.index.month

        # Calculate price changes and volatility
        df['PriceChange'] = df['Close'].pct_change()
        df['PriceVolatility'] = df['PriceChange'].rolling(window=20).std()

        # Calculate futures-specific metrics if applicable
        if 'Crypto Futures' in symbol:
            df['LeverageRatio'] = df['Volume'] / df['Close']
            df['OpenInterest'] = df['Volume'].rolling(window=20).mean()

        return df
    except Exception as e:
        print(f"Error fetching market data: {e}")
        return None

def get_time_patterns(df):
    """
    Analyze time-based patterns in the data
    """
    patterns = {}

    # Minute-based analysis (for short timeframes)
    if 'Minute' in df.columns:
        minute_returns = df.groupby(['Hour', 'Minute'])['PriceChange'].mean()
        patterns['BestMinutes'] = minute_returns.nlargest(5).index.tolist()
        patterns['WorstMinutes'] = minute_returns.nsmallest(5).index.tolist()

    # Hourly analysis
    hourly_returns = df.groupby('Hour')['PriceChange'].mean()
    patterns['BestTradingHours'] = hourly_returns.nlargest(3).index.tolist()
    patterns['WorstTradingHours'] = hourly_returns.nsmallest(3).index.tolist()

    # Daily analysis
    daily_returns = df.groupby('DayOfWeek')['PriceChange'].mean()
    patterns['BestTradingDays'] = daily_returns.nlargest(3).index.tolist()
    patterns['WorstTradingDays'] = daily_returns.nsmallest(3).index.tolist()

    # Time Prime Analysis
    volatility_by_time = df.groupby(['Hour', 'Minute'])['PriceVolatility'].mean()
    prime_times = volatility_by_time.nlargest(10)
    patterns['PrimeVolatilityPeriods'] = prime_times.index.tolist()

    # Recent High Volatility Periods
    patterns['HighVolatilityPeriods'] = df[df['PriceVolatility'] > df['PriceVolatility'].quantile(0.75)].index.tolist()

    return patterns