def get_educational_content():
    """
    Return educational content for the dashboard
    
    Returns:
        list: List of dictionaries containing educational content
    """
    return [
        {
            "title": "Understanding Candlestick Charts",
            "content": """
            Candlestick charts are a type of financial chart that shows the high, low, open, and close prices for a security.
            
            - **Green/White candle**: Closing price higher than opening price
            - **Red/Black candle**: Closing price lower than opening price
            - **Shadows**: Show the high and low prices
            
            Candlestick patterns can help identify potential market trends and reversals.
            """
        },
        {
            "title": "Technical Indicators Explained",
            "content": """
            ### Relative Strength Index (RSI)
            RSI is a momentum indicator that measures the speed and magnitude of recent price changes:
            
            - **Above 70**: Potentially overbought
            - **Below 30**: Potentially oversold
            - **50 level**: Neutral
            
            ### Moving Averages
            Moving averages help smooth out price action:
            
            - **Simple Moving Average (SMA)**: Equal weight to all prices
            - **Exponential Moving Average (EMA)**: More weight to recent prices
            """
        },
        {
            "title": "Market Analysis Basics",
            "content": """
            ### Key Concepts:
            
            1. **Trend Analysis**: Identifying the general direction of the market
            2. **Support and Resistance**: Price levels where the market tends to reverse
            3. **Volume**: Trading activity that confirms price movements
            4. **Market Psychology**: Understanding crowd behavior in markets
            
            Remember: Past performance does not guarantee future results.
            """
        }
    ]
