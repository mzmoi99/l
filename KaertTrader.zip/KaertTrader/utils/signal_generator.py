import pandas as pd
import numpy as np

def calculate_tp_sl_levels(price_df, indicators_df, signal, confidence):
    """
    Calculate Take Profit and Stop Loss levels based on technical analysis
    """
    current_price = price_df['Close'].iloc[-1]
    atr = indicators_df['ATR'].iloc[-1]

    # Base multipliers on signal confidence
    confidence_factor = confidence / 100

    if signal == 1:  # UP signal
        # Stop Loss: Below recent low, adjusted by ATR
        sl_distance = max(atr * 1.5, price_df['Low'].tail(5).min() - current_price)
        stop_loss = current_price - abs(sl_distance)

        # Take Profit: Project upward based on ATR and confidence
        tp_distance = atr * (2 + confidence_factor)
        take_profit = current_price + abs(tp_distance)

    elif signal == -1:  # DOWN signal
        # Stop Loss: Above recent high, adjusted by ATR
        sl_distance = max(atr * 1.5, current_price - price_df['High'].tail(5).max())
        stop_loss = current_price + abs(sl_distance)

        # Take Profit: Project downward based on ATR and confidence
        tp_distance = atr * (2 + confidence_factor)
        take_profit = current_price - abs(tp_distance)

    else:  # No signal
        return None, None

    return round(take_profit, 4), round(stop_loss, 4)

def generate_trading_signals(indicators_df, price_df):
    """
    Generate binary trading signals based on technical analysis

    Args:
        indicators_df (pandas.DataFrame): DataFrame with technical indicators
        price_df (pandas.DataFrame): DataFrame with price data

    Returns:
        pandas.DataFrame: DataFrame with trading signals
    """
    signals = pd.DataFrame(index=indicators_df.index)

    # RSI Signal (Oversold/Overbought)
    signals['rsi_signal'] = 0
    signals.loc[indicators_df['RSI'] < 30, 'rsi_signal'] = 1  # Oversold - Potential Up
    signals.loc[indicators_df['RSI'] > 70, 'rsi_signal'] = -1  # Overbought - Potential Down

    # Moving Average Crossover
    signals['ma_signal'] = 0
    signals.loc[indicators_df['SMA_20'] > indicators_df['EMA_50'], 'ma_signal'] = 1  # Golden Cross - Up
    signals.loc[indicators_df['SMA_20'] < indicators_df['EMA_50'], 'ma_signal'] = -1  # Death Cross - Down

    # MACD Signal
    signals['macd_signal'] = 0
    signals.loc[indicators_df['MACD'] > indicators_df['Signal_Line'], 'macd_signal'] = 1
    signals.loc[indicators_df['MACD'] < indicators_df['Signal_Line'], 'macd_signal'] = -1

    # Bollinger Bands Signal
    signals['bb_signal'] = 0
    signals.loc[price_df['Close'] < indicators_df['BB_Lower'], 'bb_signal'] = 1  # Oversold
    signals.loc[price_df['Close'] > indicators_df['BB_Upper'], 'bb_signal'] = -1  # Overbought

    # Price Momentum
    price_change = price_df['Close'].pct_change()
    signals['momentum_signal'] = 0
    signals.loc[price_change > 0.01, 'momentum_signal'] = 1  # Strong Up
    signals.loc[price_change < -0.01, 'momentum_signal'] = -1  # Strong Down

    # Volume Analysis
    volume_ma = price_df['Volume'].rolling(window=20).mean()
    signals['volume_signal'] = 0
    signals.loc[(price_df['Volume'] > volume_ma * 1.5) & (price_change > 0), 'volume_signal'] = 1
    signals.loc[(price_df['Volume'] > volume_ma * 1.5) & (price_change < 0), 'volume_signal'] = -1

    # Futures-Specific Signals (if available)
    if 'LeverageRatio' in price_df.columns:
        signals['leverage_signal'] = 0
        leverage_ma = price_df['LeverageRatio'].rolling(window=20).mean()
        signals.loc[price_df['LeverageRatio'] > leverage_ma * 1.2, 'leverage_signal'] = 1
        signals.loc[price_df['LeverageRatio'] < leverage_ma * 0.8, 'leverage_signal'] = -1
    else:
        signals['leverage_signal'] = 0

    # Combined Signal
    signal_columns = ['rsi_signal', 'ma_signal', 'macd_signal', 'bb_signal', 
                     'momentum_signal', 'volume_signal', 'leverage_signal']
    signals['total_signal'] = signals[signal_columns].sum(axis=1)

    # Final Binary Signal
    signals['binary_signal'] = 0
    signals.loc[signals['total_signal'] > 0, 'binary_signal'] = 1  # UP
    signals.loc[signals['total_signal'] < 0, 'binary_signal'] = -1  # DOWN

    # Signal Confidence (0-100%)
    max_signals = len(signal_columns)
    signals['confidence'] = (abs(signals['total_signal']) / max_signals) * 100

    # Signal Strength Categorization
    signals['strength'] = 'Neutral'
    signals.loc[signals['confidence'] > 80, 'strength'] = 'Very Strong'
    signals.loc[(signals['confidence'] <= 80) & (signals['confidence'] > 60), 'strength'] = 'Strong'
    signals.loc[(signals['confidence'] <= 60) & (signals['confidence'] > 40), 'strength'] = 'Moderate'
    signals.loc[signals['confidence'] <= 40, 'strength'] = 'Weak'

    # Calculate TP/SL for the latest signal
    latest_tp, latest_sl = calculate_tp_sl_levels(
        price_df, 
        indicators_df, 
        signals['binary_signal'].iloc[-1], 
        signals['confidence'].iloc[-1]
    )

    # Add TP/SL to signals
    signals['take_profit'] = None
    signals['stop_loss'] = None
    if latest_tp is not None and latest_sl is not None:
        signals.loc[signals.index[-1], 'take_profit'] = latest_tp
        signals.loc[signals.index[-1], 'stop_loss'] = latest_sl

    return signals